import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.*;
import java.text.DateFormat;
import java.util.Date;
import java.util.Random;
import java.util.TimeZone;

public class Staff implements Runnable {

	Socket client; 
	Staff(Socket client) {
		this.client = client;
	}
	@Override
	public void run() {

		System.out.println("Client is here");
		try {
		OutputStream out = client.getOutputStream();
		InputStream in = client.getInputStream();
		byte buff[] = new byte[64*1024];
		// Get path
		int r = in.read(buff);
		String request = new String(buff, 0, r);
		String path = getRequest(request);
		
		//400  ?
		if (path == null) {
            
            out.write(BadRequest(path).getBytes());
            client.close();
            System.out.println("Path is empty");
            return;
		}else {
			StringBuilder BuilderPath = new StringBuilder();
			if (path.getBytes()[0] != '/') {
				BuilderPath.append("/home/sergey/Personal data/Eclipse-workspace/Java/TCPServer/some/").append(path);
				path = BuilderPath.toString();
			}
			System.out.println("Path: " + path);
		}
		
		//Existence of a file
		File f = new File(path);
		boolean flag = !f.exists();
		System.out.println(flag);

        // 404 
        if(flag)
        {      
        	NotFound(out, path, buff);
            client.close();
            return;
        }else {
        	System.out.println("File is found");
        }
        
        //Type of answer
         
        String mime = "text/plain";
        
        r = path.lastIndexOf(".") +1;
        String type = path.substring(r);
        switch(type){
        case "html":
        	mime = "text/html";
        	break;
        case "jpeg":
        	mime = "image/jpeg";
        	break;
        case "gif":
        	mime = "image/gif";
        	break;
        case "txt":
        	mime = "text/txt";
        	break;
        default:
        	System.out.println("Unknown type");
        	return;
        }
       //Answer
        DateFormat df = DateFormat.getTimeInstance();
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        String response = "HTTP/1.1 200 OK\n"
        		+ "Last-Modified: " + df.format(new Date(f.lastModified())) + "\n" 
	            + "Content-Length: " + f.length() + "\n" 
	            + "Content-Type: " + mime + "\n"
	            + "Connection: close\n"
	            + "Server: SimpleWEBServer\n\n";
        out.write(response.getBytes());

        FileInputStream fis = new FileInputStream(path);
        r = 1;
        while(r > 0)
        {
            r = fis.read(buff);
            if(r > 0) out.write(buff, 0, r);
        }
        fis.close();
        client.close();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
        System.out.println("Client is gone");		
	}
	private static String getRequest(String request) throws ArrayIndexOutOfBoundsException
	{
		String URI = extract(request, "GET ", " ");
		if(URI == null) URI = extract(request, "POST ", " ");
      	if(URI == null) return null;

      	URI = URI.substring(1);
		return URI;
	}
	protected static String BadRequest(String path) {
		
        DateFormat df = DateFormat.getTimeInstance();
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        String response = "HTTP/1.1 400 Bad Request\n"
        + "Date: " + df.format(new Date()) + "\n"
        + "Connection: close\n"
        + "Server: SimpleWEBServer\n"
        + "Pragma: no-cache\n\n";
		return response;
	}
	protected static void NotFound(OutputStream out, String path, byte[] buff) throws IOException {
		

        DateFormat df = DateFormat.getTimeInstance();
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        File file = new File("/home/sergey/Personal data/Eclipse-workspace/Java/TCPServer/Error/");
        System.out.println(file.list().length);

        Random rand = new Random();
        int a =  rand.nextInt(file.list().length) + 1;       
        File error = new File("/home/sergey/Personal data/Eclipse-workspace/Java/TCPServer/Error/"+a+".jpg");
        String response = "HTTP/1.1 404 Not Found\n" 
	        + "Date: " + df.format(new Date()) + "\n"
	        + "Content-Length: " + error.length() + "\n" 
	        + "Content-Type: image/jpg\n"
	        + "Connection: close\n"
	        + "Server: SimpleWEBServer\n"
	        + "Pragma: no-cache\n\n";
	        //+ "File " + path + " not found!";

        System.out.println("File isn't found");
    	
    	out.write(response.getBytes());
    	FileInputStream fis = new FileInputStream("/home/sergey/Personal data/Eclipse-workspace/Java/TCPServer/Error/"+a+".jpg");
         a = 1;
         while(a > 0)
         {
             a = fis.read(buff);
             if(a > 0) out.write(buff, 0, a);
         }
         fis.close();
        
		return ;
	}
	protected static String extract(String str, String start, String end)
	{
		int s = str.indexOf("\n\n", 0), e;
	    if(s < 0) s = str.indexOf("\r\n\r\n", 0);
	    if(s > 0) str = str.substring(0, s);
	    s = str.indexOf(start, 0)+start.length();
	    if(s < start.length()) return null;
	    e = str.indexOf(end, s);
	    if(e < 0) e = str.length();
	    return (str.substring(s, e)).trim();
	 }
	

}
