import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.*;
import java.net.*;

public class Server {

	private static ServerSocket server;
	private static ExecutorService ClientManager;
	
	public static void main(String[] args) throws IOException{
		 
		try {
			server = new ServerSocket(9999);
			System.out.println("I'm in " + server.getLocalPort() + " port ^_^");
			ClientManager =  Executors.newFixedThreadPool(10);
				while(true) {
					ClientManager.execute(new Staff(server.accept()));
					System.out.println("New potok");
				}
			}
		catch (Exception e) {
			System.out.println("We're in shit(");
			ClientManager.shutdown();
			server.close();
			e.printStackTrace();
		}
	}
}