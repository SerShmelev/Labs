package ru.applmath.valutes.export;

import com.mongodb.*;

import java.util.ArrayList;
import java.util.List;

public class MongoDatabaseReader {
    public List<DBObject> getValute(String nameValute) {
        List<DBObject> listDBObj = new ArrayList<DBObject>();
        try {
            Mongo mongoClient = new Mongo("127.0.0.1");
            DB db = mongoClient.getDB("forex");
            DBCollection collection = db.getCollection("valutes");

            BasicDBObject searchQuery = new BasicDBObject();
            searchQuery.put("valuteName", nameValute);
            DBCursor cursor = collection.find(searchQuery);

            for (DBObject dbObject : cursor) {
                listDBObj.add(dbObject);
                cursor.next();
            }

            mongoClient.close();

        } catch (Throwable t) {
            throw new RuntimeException(t);
        }

        return listDBObj;
    }
}
