package ru.applmath.valutes.export;

import java.awt.Color;
import java.awt.Dimension;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import com.mongodb.DBObject;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.*;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.general.SeriesException;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import sun.util.calendar.BaseCalendar;
import sun.util.calendar.LocalGregorianCalendar;

public class Grafik extends ApplicationFrame {

    private static final long serialVersionUID = 1L;

    public Grafik(String title, List<DBObject> list) {
        super(title);
        final XYDataset dataset = createDataset(list);
        final JFreeChart chart = createChart(dataset);
        chart.setTitle(title);

        final ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(600, 350));
        setContentPane(chartPanel);
    }

    public XYDataset createDataset(List<DBObject> list) {
        TimeSeries series1 = new TimeSeries(list.get(0).get("valuteName").toString());
        java.util.Date date = new java.util.Date();
        for(DBObject o : list) {
            double y = (Double) o.get("valuteValue");
            try{
            series1.add(new Day((java.util.Date) o.get("date")),y);
            }
            catch (SeriesException a)
            {
                //a.printStackTrace();
            }
        }

        TimeSeriesCollection dataset = new TimeSeriesCollection();
        dataset.addSeries(series1);

        return dataset;
    }

    private JFreeChart createChart(final XYDataset dataset) {

        final JFreeChart chart = ChartFactory.createXYLineChart(
                "",                        // chart title
                "",                        // domain axis label
                "",                        // range axis label
                dataset,                   // data
                PlotOrientation.VERTICAL,  // orientation
                true,                      // include legend
                true,                      // tooltips
                false                      // urls
        );

        chart.setBackgroundPaint(Color.WHITE);
        XYPlot plot = (XYPlot) chart.getPlot(); //get the plot

        //Create the new date axis for y
        DateAxis yDateAxis = new DateAxis();
        //Set desired time format
        DateFormat dateFormat = new SimpleDateFormat("hh - dd - MMM - yyyy");
        //yDateAxis.setDateFormatOverride(dateFormat);
        //Add your own Tickunit if you like (you can do with out also, comment out the below line and let JFreeChart decided)
        //Set the new y-axis to the plot
        plot.setDomainAxis(yDateAxis);

        return chart;
    }
}