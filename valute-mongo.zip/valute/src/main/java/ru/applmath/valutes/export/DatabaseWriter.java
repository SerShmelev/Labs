package ru.applmath.valutes.export;

import java.util.ArrayList;
import java.util.List;
import ru.applmath.valutes.export.*;

public interface DatabaseWriter {
	void writeToDatabase(List<Valute> v);
}
