package ru.applmath.valutes.export;

import java.util.Calendar;
import java.util.Date;

public class Valute {
	
	private Date date;

	private String id;

	private String charCode;
	
	private int nominal;

	private String name;

	private double value; // TODO: Do NOT use floating point value for MONEY !!!

	public void setDate(Date date) {
		this.date = date;
	}
	
	public Date getDate() {
		return date;
	}
	
	public int getNominal() {
		return nominal;
	}
	
	public void setNominal(int nominal) {
		this.nominal = nominal;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCharCode() {
		return charCode;
	}

	public void setCharCode(String charCode) {
		this.charCode = charCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "[" + id + "; " + charCode + "; " + date + "; " + nominal + "; " + name + "; " + value + "]";
	}
}
