package ru.applmath.valutes.export;



import java.io.*;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Scanner;

import javax.swing.JFrame;

import org.jfree.ui.RefineryUtilities;
import org.knowm.xchart.QuickChart;
import org.knowm.xchart.SwingWrapper;
import org.knowm.xchart.XYChart;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Main {
	public static void main(String[] args) {
		
//		ValutesReader vr = new CbrValutesReader();
//		Calendar begin_date = GregorianCalendar.getInstance();
//		begin_date.set(2012, 01, 10, 0, 0, 0);
//		DatabaseWriter dbwr = new MongoDatabaseWriter();
//		Calendar end_date = GregorianCalendar.getInstance();
//
//		List<Valute> listValute;
//		while(end_date.after(begin_date) ) {					
//			listValute = vr.getValutes(begin_date.getTime());
//			for(Valute lv : listValute)
//				lv.setDate(begin_date.getTime());
//						
//			begin_date.add(GregorianCalendar.DAY_OF_MONTH, 1);
//			System.out.println("date >> " + begin_date.getTime());
//			
//			dbwr.writeToDatabase(listValute);
//			listValute.clear();
//		}
//		
//		System.out.println("Done!!!!!");
//	
		


		List<DBObject> listDBObject = new ArrayList<DBObject>();
		List<String> str = new ArrayList<String>();
		//List<String> val = new ArrayList<String>();
		try {
			Mongo mongoClient = new Mongo("127.0.0.1");
			DB db = mongoClient.getDB("forex");
			DBCollection collection = db.getCollection("valutes");
			DBCursor cursor = collection.find();
			
			for (DBObject dbObject : cursor) {
				listDBObject.add(dbObject);
		        cursor.next();
			}
			System.out.println("Document contains: " + listDBObject.size());
			
			int i = 0;
			while(true) {
				str.add(listDBObject.get(i).get("valuteName").toString());
			//	val.add(listDBObj.get(i).get("valuteValue").toString());
				
				if(i != 0 && str.get(0).equals(str.get(i))) {
					str.remove(i);
					break;
				}
				i++;
			}
			
			mongoClient.close();
			
		} catch (Throwable t) {
			throw new RuntimeException(t);
		}
					
		String nameValute = null;
		while(true)
		{
			int o = 1;
		
			for(String s : str) {
				System.out.println(o+ " : "+s);
				o++;
				
				
			}
			System.out.println("Введите 0, что бы выйти ");
			System.out.print("> ");
		
			int a;
			Scanner scn = new Scanner(System.in);
			a = scn.nextInt() - 1;
			if (a == -1) {
				System.out.println("Досвидания ^_^");
				return;
			}
			try {
				System.out.println("==========> "+ str.get(a));
				nameValute = str.get(a);
				
				MongoDatabaseReader mdr = new MongoDatabaseReader();
				List<DBObject> listDBObj = mdr.getValute(nameValute);
				
				computation(listDBObj);//Вычисления
				
				
				final Grafik grafik = new Grafik(nameValute,listDBObj);//График
				grafik.pack();	
				RefineryUtilities.centerFrameOnScreen(grafik);
				grafik.setVisible(true);
				
				
				System.out.println("Хотите продолжить?(1-Да)");
				System.out.print("> ");
				a = scn.nextInt();
				if (a != 0)
					return;
					
			}catch (IndexOutOfBoundsException e) {
				System.out.println("Такой валюты нет!! Попробуйте снова)");
			}
		}

	}
	
	private static void computation(List<DBObject> listDBObj) {
		double max = (Double) listDBObj.get(0).get("valuteValue");
		double min = (Double) listDBObj.get(0).get("valuteValue");
		double sum = 0;
		int i = 0;
		for(DBObject obj : listDBObj) {
			if(max < (Double) obj.get("valuteValue")) max = (Double) obj.get("valuteValue");
			if(min > (Double) obj.get("valuteValue")) min = (Double) obj.get("valuteValue");
			sum += (Double) obj.get("valuteValue");
			i++;
		}
		double avg = sum/i;
		System.out.println("Max = " + max + "		Min = " + min + "		Avg = " + avg);
	}
	
}
